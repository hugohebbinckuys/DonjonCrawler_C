#include "constructeur.h"
#include <string.h>
#include <stdio.h>

int main () {
    fonction_finale(); 

    return 0; 
}
